package com.tony.infraProjc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InfraProjcApplicationTests {

	@Test
	void contextLoads() {
	}

}
